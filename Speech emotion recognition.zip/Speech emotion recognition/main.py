import soundfile # to read audio file
import numpy as np # libray to work with arrays
import librosa # to extract speech features
import glob # to handle the files
import os # for directries/paths of files
import pickle # to save model after training
from sklearn.model_selection import train_test_split # for splitting training and testing
from sklearn.neural_network import MLPClassifier # multi-layer perceptron model
from sklearn.metrics import accuracy_score # to measure how good we are
from sklearn.ensemble import RandomForestClassifier # to import random forest classifier
from sklearn.svm import SVC
import sounddevice as sd # to play with audios
from scipy.io.wavfile import write # forsaving the audio files


#function to extract features from audio(.wav) files
def extract_feature(file_name, **kwargs):
    """
    Extract feature from audio file `file_name`
        Features supported:
            - MFCC (mfcc)
            - Chroma (chroma)
            - MEL Spectrogram Frequency (mel)
            - Contrast (contrast)
            - Tonnetz (tonnetz)
        e.g:
        `features = extract_feature(path, mel=True, mfcc=True)`
    """
    mfcc = kwargs.get("mfcc")#windowing the signal, applying the DFT, taking the log of the magnitude, and then warping the frequencies on a Mel scale, followed by applying the inverse DCT
    chroma = kwargs.get("chroma")#tonal content of a musical audio signal in a condensed form.
    mel = kwargs.get("mel")#mel-frequency cepstrum (MFC) is a representation of the short-term power spectrum of a sound, based on a linear cosine transform of a log power spectrum on a nonlinear mel scale of frequency.
    contrast = kwargs.get("contrast")#Difference between sounds
    tonnetz = kwargs.get("tonnetz")
    with soundfile.SoundFile(file_name) as sound_file:
        X = sound_file.read(dtype="float32")
        sample_rate = sound_file.samplerate
        if chroma or contrast:
            stft = np.abs(librosa.stft(X))
        result = np.array([])
        if mfcc:
            mfccs = np.mean(librosa.feature.mfcc(y=X, sr=sample_rate, n_mfcc=40).T, axis=0)
            result = np.hstack((result, mfccs))
        if chroma:
            chroma = np.mean(librosa.feature.chroma_stft(S=stft, sr=sample_rate).T,axis=0)
            result = np.hstack((result, chroma))
        if mel:
            mel = np.mean(librosa.feature.melspectrogram(X, sr=sample_rate).T,axis=0)
            result = np.hstack((result, mel))

    return result


lbl2emotion = {
    "N": "neutral",
    "H": "happy",
    "S": "sad",
    "A": "angry"
}


#function to laod data audio from files
def load_data(test_size=0.3):
    X, y = [], []
    print("Loadiing the data from disk...")
    for file in glob.glob("DATA_SET/*/*.wav"):
        # get the base name of the audio file
        basename = os.path.basename(file)
        # get the emotion label
        emotion = lbl2emotion[basename.split("_")[2]]
        # extract speech features
        features = extract_feature(file, mfcc=True, chroma=True, mel=True)
        # add to data
        X.append(features)
        y.append(emotion)
    # split the data to training and testing and return it
    return train_test_split(np.array(X), y, test_size=test_size, random_state=7)


#loading the data into arrays
X_train, X_test, y_train, y_test = load_data(test_size=0.3)
# # print some details
# # number of samples in training data
# print("[+] Number of training samples:",X_train.shape[0])
# # number of samples in testing data
# print("[+] Number of testing samples 331:",X_test.shape[0])



# best parameters for MLP determined by a grid search
MLPmodel_params = {
    'alpha': 0.01,
    #'batch_size': 256,
    'epsilon': 1e-08,
    'hidden_layer_sizes': (300,),
    'learning_rate': 'adaptive',
    'max_iter': 500,
}

# initialize Multi Layer Perceptron classifier
# with best parameters ( so far )
model = MLPClassifier(**MLPmodel_params)

# train the model
print("[*] Training the model on MLP...")
model.fit(X_train, y_train)

# predict 30% of data to measure how good we are
y_pred = model.predict(X_test)

# calculate the accuracy
accuracy = accuracy_score(y_true=y_test, y_pred=y_pred)

print("Accuracy: {:.3f}%".format(accuracy*100))

# now we save the model
# make result directory if doesn't exist yet
if not os.path.isdir("result"):
    os.mkdir("result")

pickle.dump(model, open("result/mlp_classifier.model", "wb"))








RFmodel_params = {
    'n_estimators':100,
    'criterion':"entropy",
}

# initialize RandomForestClassifier
# with best parameters ( so far )
model1 = RandomForestClassifier(n_estimators=100,criterion="entropy")

# train the model
print("[*] Training the model on RF...")
model1.fit(X_train, y_train)

# predict 30% of data to measure how good we are
y_pred = model1.predict(X_test)

# calculate the accuracy
accuracy = accuracy_score(y_true=y_test, y_pred=y_pred)

print("Accuracy: {:.3f}%".format(accuracy*100))

# now we save the model
# make result directory if doesn't exist yet
if not os.path.isdir("result"):
    os.mkdir("result")

pickle.dump(model, open("result/mlp_classifier.model", "wb"))








model1 = SVC()

# train the model
print("[*] Training the model on SVM...")
model1.fit(X_train, y_train)

# predict 30% of data to measure how good we are
y_pred = model1.predict(X_test)

# calculate the accuracy
accuracy = accuracy_score(y_true=y_test, y_pred=y_pred)

print("Accuracy: {:.3f}%".format(accuracy*100))

# now we save the model
# make result directory if doesn't exist yet
if not os.path.isdir("result"):
    os.mkdir("result")

pickle.dump(model, open("result/mlp_classifier.model", "wb"))

# while True:
#     b = input ("Press Any key to start recording")
#     # sampling rate
#     fs = 48000
#     # duration of recording
#     seconds = 3
#     print("Start Speaking")
#     # recording the users sound
#     myRecording = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
#     # wait until recording is finished
#     sd.wait()
#     # saving the recorded sound as .wav file
#     write('RecordedData/Ehsan.wav', fs, myRecording)
#     print("Recorded")
#
#     # array to store recorded files
#     X = []
#     for file in glob.glob("RecordedData/*.wav"):
#         # extracting the features of recorded audios
#         features = extract_feature(file, mfcc=True, chroma=True, mel=True)
#         #basename = os.path.basename(file)
#         #print(basename)
#         # stor the features into an array
#         X.append(features)
#
#     # predicting the labels of recorded sounds
#     y_pred = model.predict(X)
#     y_pred1 = model1.predict(X)
#     # showing the results
#     # print("The emotion of Recorded Sound is:", y_pred[0])
#     # print("The emotion of Recorded Sound is:", y_pred[1])
#     # print("The emotion of Recorded Sound is:", y_pred[2])
#     # print("The emotion of Recorded Sound is:", y_pred[3])
#     #print("The emotion of Recorded Sound by MLP is:", y_pred[4])
#     print("The emotion of Recorded Sound by RF is:", y_pred1[4])










b = input ("Press Any key to start recording")
fs = 48000
seconds = 3
print("Start Speaking")
myRecording = sd.rec(int(seconds * fs), samplerate=fs, channels=1)
sd.wait()

write('RecordedData/Ehsan.wav', fs, myRecording)
print("Recorded")

X = []
for file in glob.glob("RecordedData/*.wav"):
    features = extract_feature(file, mfcc=True, chroma=True, mel=True)
    X.append(features)

y_pred = model.predict(X)
y_pred1 = model1.predict(X)
print("The emotion of Recorded Sound by RF is:", y_pred1[4])
